// Seleciona o container (div) das imagens
const container = document.querySelector(".image-container");

// índice para multiplicar o deslocamento do carousel
let idx = 1;

// variável para armazenar as imagens
let imgs;


const dot1 = document.getElementById('dot1');
const dot2 = document.getElementById('dot2');
const dot3 = document.getElementById('dot3');

const run = () =>{
    // necessário atualizar a lista de imagens depois de novas inserções
    imgs =  document.querySelectorAll(".image-container img");

    // Necessário reiniciar a contagem se não adicionar novas elementos no image-container
    if(idx >= imgs.length){
        idx = 0;
    }

    // faz o deslocamento proporcional ao índice da imagem sendo apresentada
    // Ex:
    //   idx 0 - deslocamento de 0px;
    //   idx 1 - deslocamento de 500px;
    //   idx 2 - deslocamento de 1000px;

    container.style.transform =
        `translateX(${-idx * 500}px)`;

    // clona o nó para adicionar ao final de image-container
    const cloneImg = imgs[idx].cloneNode();
    // Adiciona como último filho do container
    // container.insertAdjacentElement("beforeend", cloneImg);

    // código para remover uma imagem depois de um tempo
    // setTimeout(()=>{cloneImg.remove()}, 1500);
    idx++;
    console.log(idx)
}

function next() {
        run();
        changeStatus();
}

const first = () => {
    return imgs[0];
}

function prev() {
    imgs = document.querySelectorAll(".image-container img");
    if (idx === 0 ){
        first()
    } else {
        idx--;
        container.style.transform =
            `translateX(${-idx * 500}px)`;
        // clona o nó para adicionar ao final de image-container
        const cloneImg = imgs[idx].cloneNode();
        // Adiciona como último filho do container
        container.insertAdjacentElement("beforeend", cloneImg);
    }
    changeStatus()
}

const changeStatus = () => {
    if(idx === 1){
        dot1.style.backgroundColor = 'crimson';
        dot2.style.backgroundColor = 'white';
        dot3.style.backgroundColor = 'white';
    }else if(idx === 2){
        dot2.style.backgroundColor = 'crimson';
        dot1.style.backgroundColor = 'white';
        dot3.style.backgroundColor = 'white';
    } else if(idx === 3){
        dot3.style.backgroundColor = 'crimson';
        dot2.style.backgroundColor = 'white';
        dot1.style.backgroundColor = 'white';
    }
}
